# Nightsuit Costing Studio — Setup Guide

A one-page tool to build a costing sheet for each nightsuit style: fabric photo, design photo, supplier & bill details, cutting master, cutting average, cloth cost, job work, and the final MRP — calculated automatically. All your data lives in **your own Google Sheet**, and images live in **your own Google Drive folder**. No paid services, no backend server, no database.

This is a prototype — good enough to use daily, simple enough to extend yourself later.

---

## How it works

- The whole app is two files: `index.html` and `app.js`. GitHub Pages just serves these as static files.
- When you click **Sign in with Google**, the app asks Google directly (in your browser) for permission to read/write *one* spreadsheet and *one* Drive folder — the ones you point it at.
- Every "Save" writes a row to your Sheet. Every image upload goes to your Drive folder and gets set to "anyone with the link can view" so it can be displayed in the app.
- Nothing passes through any third-party server. It's just your browser talking to Google's APIs.

---

## Part 1 — Create the Google Sheet

1. Go to [sheets.google.com](https://sheets.google.com) and create a new blank spreadsheet.
2. Rename the sheet (the tab at the bottom, not the file) to exactly: **`CostingSheets`**
3. Rename the spreadsheet itself to something like "Nightsuit Costing Data".
4. Copy the **Spreadsheet ID** from the URL:
   `https://docs.google.com/spreadsheets/d/`**`THIS_LONG_ID`**`/edit`
   Save this — you'll paste it into the app's Settings later.
5. Leave the sheet otherwise empty — the app will add the header row automatically the first time you sign in.

## Part 2 — Create the Google Drive folder

1. Go to [drive.google.com](https://drive.google.com) and create a new folder, e.g. "Nightsuit Costing Images".
2. Open it, and copy the **Folder ID** from the URL:
   `https://drive.google.com/drive/folders/`**`THIS_LONG_ID`**
   Save this too.

## Part 3 — Create a free Google Cloud project (for API access)

This is the only slightly technical part — it's free and takes about 5 minutes.

1. Go to [console.cloud.google.com](https://console.cloud.google.com) and sign in with the same Google account.
2. Create a new project (top-left project dropdown → **New Project**). Name it anything, e.g. "Nightsuit Costing".
3. With that project selected, go to **APIs & Services → Library** and enable these two:
   - **Google Sheets API**
   - **Google Drive API**
4. Go to **APIs & Services → OAuth consent screen**:
   - User type: **External**
   - Fill in an app name (e.g. "Nightsuit Costing Studio"), your email for support and developer contact.
   - Add scopes: search for and add `.../auth/spreadsheets` and `.../auth/drive.file`.
   - Under **Test users**, add your own Google account email. (While the app is in "Testing" mode, only accounts you add here can sign in — that's fine, since only you will use this.)
5. Go to **APIs & Services → Credentials**:
   - Click **Create Credentials → API key**. Copy it. Optionally click "Restrict key" and limit it to the Sheets API and Drive API.
   - Click **Create Credentials → OAuth client ID**.
     - Application type: **Web application**
     - Under **Authorized JavaScript origins**, add the URL where you'll host this app, e.g.:
       `https://yourusername.github.io`
       (also add `http://localhost:8000` if you want to test locally first)
     - Create it, then copy the **Client ID**.

You now have four things saved: **Client ID**, **API Key**, **Spreadsheet ID**, **Folder ID**.

## Part 4 — Host it for free on GitHub Pages

1. Create a new **public** GitHub repository, e.g. `nightsuit-costing`.
2. Upload `index.html` and `app.js` (this folder's contents) to the repo — either via the GitHub website's "Add file → Upload files", or with git:
   ```
   git init
   git add index.html app.js
   git commit -m "Nightsuit costing studio prototype"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/nightsuit-costing.git
   git push -u origin main
   ```
3. In the repo, go to **Settings → Pages**.
   - Source: **Deploy from a branch**
   - Branch: **main**, folder: **/ (root)**
   - Save. GitHub will give you a URL like `https://yourusername.github.io/nightsuit-costing/`.
4. Make sure that exact URL's origin (`https://yourusername.github.io`) is in your OAuth Client's **Authorized JavaScript origins** from Part 3 — if you added it after creating the client, edit the client and add it now.

## Part 5 — Use the app

1. Open your GitHub Pages URL.
2. Click **Settings** (top right) and paste in your Client ID, API Key, Sheet ID, and Folder ID. Save.
3. Click **Sign in with Google** and approve access. Since the app is in "Testing" mode, you may see an "unverified app" warning — click **Advanced → Go to (app name)** to continue. This is expected for an app only you use.
4. Fill in a costing sheet under **New Style** and click **Save costing sheet**.
5. Check **All Styles** to see everything you've saved, view full details, or delete an entry.

Your data is always visible and editable directly in the Google Sheet too, if you ever want to work in bulk (e.g. quickly editing many rows, or building charts).

---

## Notes on the costing formulas used

Fabric is costed by weight (kg), not length, since that's how you buy and bill it:

- **Fabric price per kg** = Total bill amount ÷ Total fabric purchased (kg) — you enter the two totals from your bill, the rate is derived automatically
- **Total average cloth used** = Avg fabric used per piece (kg) × Number of pieces
- **Fabric cost per piece** = Fabric price per kg × Avg fabric used per piece (kg)
- **Total fabric cost** = Fabric price per kg × Total average cloth used
- **Variable cost per piece** = Fabric cost per piece + Job work cost per piece
- **Final MRP** = (Variable cost per piece + Fixed cost per piece) × (1 + Profit % / 100)

Fabric length, width and GSM are still captured as reference specs for the roll (useful for reordering the same fabric later), but they don't feed into the cost math — the kg average you enter is what drives cost.

If your fixed cost or profit logic works differently in practice, these are plain calculations inside `app.js` (`recalc()` function) — easy to adjust.

## Limits of this prototype

- One sheet tab (`CostingSheets`) holds every style as a row — fine for hundreds of styles.
- Editing an existing entry isn't built yet (only add/view/delete) — for now, edit directly in the Google Sheet if needed, or delete and re-add.
- The OAuth consent screen stays in "Testing" mode (fine for personal/internal use by a few emails you add as test users). If you ever want other teammates to sign in without being added as test users, Google requires app verification for production mode — not necessary for solo/internal use.
